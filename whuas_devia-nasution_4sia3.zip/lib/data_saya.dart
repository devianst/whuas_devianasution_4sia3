class DataSaya {
  static String nama = "Kudut";
  static String gambar = "assets/mahasiswa/kudut.png";
}
